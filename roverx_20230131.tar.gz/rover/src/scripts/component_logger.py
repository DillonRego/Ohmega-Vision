import time
import sys
import random
import os

from typing import Dict, List

DISPLAY_DECIMALS = 4

class UNIT:
    CELCIUS = "˚C"
    VOLTAGE = "V"
    WATTS = "W"
    AMPS = "A"
    ACCELERATION = "m/s^2"
    MICRO_TELSA = "µT"
    RADS_PER_SEC = "rad/s"
    RPM = "rpm"
    NONE = ""

class TerminalController:
    BLACK_ANSI = "\x1b[30m"
    RED_ANSI = "\x1b[31m"
    GREEN_ANSI = "\x1b[32m"
    YELLOW_ANSI = "\x1b[33m"
    BLUE_ANSI = "\x1b[34m"
    MAGENTA_ANSI = "\x1b[35m"
    CYAN_ANSI = "\x1b[36m"
    WHITE_ANSI = "\x1b[37m"

    def __init__(self):
        self.cursor_row = 1

    def move_cursor(self, y, x):
        print("\033[%d;%dH" % (y, x))

    def print_newline(self, message):
        self.move_cursor(self.cursor_row, 1)
        print(message)
        self.cursor_row += 1

class ComponentMeasurement:
    def __init__(self, name: str, func_pointer: classmethod, meas_unit: str):
        self.name = name
        self.func_pointer = func_pointer
        self.meas_unit = meas_unit
        self.current_value = None
        
    def update_value(self):
        try:
            self.current_value = self.func_pointer()
            
        except Exception as e:
            self.current_value = str(e)

class Subsystem:    
    def __init__(self, name, color: str = TerminalController.WHITE_ANSI):
        self.name = name
        self.num_measurements = 0
        self.measurements = []

        if color.startswith('\x1b[') and color.endswith('m') and \
            (color[3].isdigit() and int(color[3]) <= 7 and int(color[3]) >= 0):
                self.color = color
        else:
            self.color = TerminalController.WHITE_ANSI

    def add_component_meas(self, comp: ComponentMeasurement):
        if comp == None or type(comp) != ComponentMeasurement or comp.name == None or comp.name == "":
            raise(Exception(f"Invalid Component Measurement trying to be added to Subsytem: {self.name}"))
        self.measurements.append(comp)
        self.num_measurements += 1
        
    def add_component_meas_list(self, comp_list: List[ComponentMeasurement]):
        for comp in comp_list:
            if comp == None or type(comp) != ComponentMeasurement or comp.name == None or comp.name == "":
                raise(Exception(f"Invalid Component Measurement trying to be added to Subsytem: {self.name}"))
            self.measurements.append(comp)
            self.num_measurements += 1
        
    def update_measurements(self):
        for i in range(self.num_measurements):
            self.measurements[i].update_value()
        
def random_val():
    return random.randint(70, 99)

def mock_main():
    # manually change options in code
    is_writting_log = True
    is_std_out = True
    iter_length = 525600 * 60
    
    term_control = TerminalController()

    battery_subsystem = Subsystem("Battery", TerminalController.BLUE_ANSI)
    battery_subsystem.add_component_meas(ComponentMeasurement("Internal Temperature", lambda : random.randint(-40, 125), UNIT.CELCIUS))
    battery_subsystem.add_component_meas(ComponentMeasurement("External Temperature", lambda : random.randint(-40, 125), UNIT.CELCIUS))
    battery_subsystem.add_component_meas(ComponentMeasurement("Cell 0 Voltage", random_val, UNIT.VOLTAGE))
    battery_subsystem.add_component_meas(ComponentMeasurement("Cell 1 Voltage", random_val, UNIT.VOLTAGE))
    battery_subsystem.add_component_meas(ComponentMeasurement("Cell 2 Voltage", random_val, UNIT.VOLTAGE))
    battery_subsystem.add_component_meas(ComponentMeasurement("Cell 3 Voltage", random_val, UNIT.VOLTAGE))
    
    movement_subsystem = Subsystem("Movement", TerminalController.GREEN_ANSI)
    movement_subsystem.add_component_meas(ComponentMeasurement("Motor FR Voltage", random_val, UNIT.VOLTAGE))
    movement_subsystem.add_component_meas(ComponentMeasurement("Motor FRT Voltage", random_val, UNIT.VOLTAGE))
    movement_subsystem.add_component_meas(ComponentMeasurement("Motor FL Voltage", random_val, UNIT.VOLTAGE))
    movement_subsystem.add_component_meas(ComponentMeasurement("Motor FLT Voltage", random_val, UNIT.VOLTAGE))
    movement_subsystem.add_component_meas(ComponentMeasurement("Motor BR Voltage", random_val, UNIT.VOLTAGE))
    movement_subsystem.add_component_meas(ComponentMeasurement("Motor BRT Voltage", random_val, UNIT.VOLTAGE))
    movement_subsystem.add_component_meas(ComponentMeasurement("Motor BL Voltage", random_val, UNIT.VOLTAGE))
    movement_subsystem.add_component_meas(ComponentMeasurement("Motor BLT Voltage", random_val, UNIT.VOLTAGE))
    
    subsystems = [battery_subsystem, movement_subsystem]
    
    num_functions = 0
    for system in subsystems:
        num_functions += system.num_measurements
    
    term_control.cursor_row = 2 + len(subsystems) + num_functions

    if is_writting_log and is_std_out:
        logger_stdout_trace_log(term_control, subsystems, iter_length)
    elif is_writting_log:
        logger_no_std_out(term_control, subsystems, iter_length)
    else:
        logger_no_write(term_control, subsystems, iter_length)

def logger_stdout_trace_log(term_control: TerminalController, subsystems: List[Subsystem], iter_len: int):
    out_file = open("trace_file.log", "w")
    os.system('cls' if os.name == 'nt' else 'clear') # Platform agnostic
    # Fake timing
    for i in range(iter_len):
        new_data_collection = {}
        new_data_str = ""
        for system in subsystems:
            system.update_measurements()
            new_data_collection[system.name] = {}
            new_data_str += f"{system.color}{system.name}:\n"
            for meas in system.measurements:
                try:
                    float(str(meas.current_value))
                    new_data_collection[system.name][meas.name] = meas.current_value
                    
                    new_data_str += f"\t{system.color}{meas.name:20s}: {TerminalController.WHITE_ANSI}{meas.current_value:0.4f} {meas.meas_unit:20s}\n"
                except: # ignore non numeric values for graphing
                    new_data_str += f"\t{system.color}{meas.name:20s}: {TerminalController.WHITE_ANSI}{str(meas.current_value):12s} {meas.meas_unit:20s}\n"

        new_data_str += '---------------------\n'
        term_control.move_cursor(1, 1)
        print(new_data_str)

        out_file.write(str(new_data_collection) + '\n')
        out_file.flush()

        term_control.move_cursor(term_control.cursor_row, 1)
        if i % 10 == 0:
            term_control.print_newline("Example Non Power Log Message or Error")

        time.sleep(1)

def logger_no_std_out(term_control: TerminalController, subsystems: List[Subsystem], iter_len: int):
    out_file = open("trace_file.log", "w")

    # Fake timing
    for i in range(iter_len):
        new_data_collection = {}
        for system in subsystems:
            system.update_measurements()
            new_data_collection[system.name] = {}
            for meas in system.measurements:
                try:
                    float(str(meas.current_value))
                    new_data_collection[system.name][meas.name] = meas.current_value
                except: # ignore non numeric values for graphing
                    pass

        out_file.write(str(new_data_collection) + '\n')

        time.sleep(1)

def logger_no_write(term_control: TerminalController, subsystems: List[Subsystem], iter_len: int):
    os.system('cls' if os.name == 'nt' else 'clear') # Platform agnostic

    # Fake timing
    for i in range(iter_len):
        new_data_str = ""
        for system in subsystems:
            system.update_measurements()
            new_data_str += f"{system.color}{system.name}:\n"
            for meas in system.measurements:
                try:
                    float(str(meas.current_value))
                    
                    new_data_str += f"\t{system.color}{meas.name:20s}: {TerminalController.WHITE_ANSI}{meas.current_value:0.4f} {meas.meas_unit:20s}\n"
                except: # ignore non numeric values for graphing
                    new_data_str += f"\t{system.color}{meas.name:20s}: {TerminalController.WHITE_ANSI}{str(meas.current_value):12s} {meas.meas_unit:20s}\n"

        new_data_str += '---------------------\n'
        term_control.move_cursor(1, 1)
        print(new_data_str)

        term_control.move_cursor(term_control.cursor_row, 1)
        if i % 10 == 0:
            term_control.print_newline("Example Non Power Log Message or Error")

        time.sleep(1)

"""
TODO: add more subsystems by following the format with
 subsystem lists and dicts within the try catch blocks
 
 Subsystem object needs to be created with a name and a Terminal Color
 Then a component dictionary needs to be created:
    The schema format will contain keys to lists of ComponentMeasurement objects
    ex:
    dictionary = {
        "key1": [ComponentMeasurement1, ComponentMeasurement2, ...],
        "key2": [ComponentMeasurement1, ComponentMeasurement2, ...],
        ...
    }
The Subystem object and the subsystem dictionary need to be appended to their
respected lists to be read by the component logger:

subsystems.append(new_subsystem)
subsystem_dict.append(new_subsystem_dict)
"""
def init_subsystems():
    subsystems: List[Subsystem] = []
    subsystem_dict: List[Dict] = []

    try:
        from rover.battery import Battery, BatteryRegister
        
        battery = Battery()
        battery.read_current_gain() # just to verify i2c with battery
        battery_subsystem = Subsystem("Stellar Exploration Battery", TerminalController.BLUE_ANSI)
        battery_comp_map = {
            "power": [
                ComponentMeasurement("Battery Voltage", lambda : battery.read_register(battery.VBATT_VOLT), UNIT.VOLTAGE),
                ComponentMeasurement("Pack Current", lambda : battery.read_register(battery.PACK_CURRENT), UNIT.AMPS),
                ComponentMeasurement("Power Usage", lambda : battery.read_register(battery.PACK_CURRENT) * battery.read_register(battery.VBATT_VOLT), UNIT.WATTS)
                ],
            "temperature": [
                ComponentMeasurement("Internal Temperature", lambda : battery.int_temp_celcius(battery.read_register(battery.INTERNAL_TEMP_VOLT)), UNIT.CELCIUS),
                ComponentMeasurement("External Temperature", lambda : battery.ext_temp_celcius(battery.read_register(battery.EXTERNAL_TEMP_1_VOLT)), UNIT.VOLTAGE)
            ],
            "cell_voltage": [
                ComponentMeasurement("Cell 0 Voltage", lambda : battery.read_register(battery.CELL_VOLTS[0]), UNIT.VOLTAGE),
                ComponentMeasurement("Cell 1 Voltage", lambda : battery.read_register(battery.CELL_VOLTS[1]), UNIT.VOLTAGE),
                ComponentMeasurement("Cell 2 Voltage", lambda : battery.read_register(battery.CELL_VOLTS[2]), UNIT.VOLTAGE),
                ComponentMeasurement("Cell 3 Voltage", lambda : battery.read_register(battery.CELL_VOLTS[3]), UNIT.VOLTAGE),
                ComponentMeasurement("Cell 4 Voltage", lambda : battery.read_register(battery.CELL_VOLTS[4]), UNIT.VOLTAGE),
                ComponentMeasurement("Cell 5 Voltage", lambda : battery.read_register(battery.CELL_VOLTS[5]), UNIT.VOLTAGE),
                ComponentMeasurement("Cell 6 Voltage", lambda : battery.read_register(battery.CELL_VOLTS[6]), UNIT.VOLTAGE),
                ComponentMeasurement("Cell 7 Voltage", lambda : battery.read_register(battery.CELL_VOLTS[7]), UNIT.VOLTAGE)
            ],
            "bit_registers": [
                ComponentMeasurement("Read 0x80", lambda : battery.read_register(BatteryRegister(1, 0x80, BatteryRegister.BIT_DICT)), UNIT.NONE),
                ComponentMeasurement("Read 0x81", lambda : battery.read_register(BatteryRegister(1, 0x81, BatteryRegister.BIT_DICT)), UNIT.NONE),
                ComponentMeasurement("Read 0x82", lambda : battery.read_register(BatteryRegister(1, 0x82, BatteryRegister.BIT_DICT)), UNIT.NONE),
                ComponentMeasurement("Read 0x82", lambda : battery.read_register(BatteryRegister(1, 0x83, BatteryRegister.BIT_DICT)), UNIT.NONE)
            ]
        }

        subsystems.append(battery_subsystem)
        subsystem_dict.append(battery_comp_map)
    except Exception as e:
        print(f"Unable to mount Battery Subsystem: {e}")

    try:
        from rover.imu import Imu
        
        imu_reference = Imu()
        imu_subsystem = Subsystem("IMU (Intertial Measurement Unit)", TerminalController.YELLOW_ANSI)
        imu_comp_map = {
            "accelerometer": [ComponentMeasurement("Accelerometer", lambda : imu_reference.strAccel(), UNIT.ACCELERATION)],
            "magnetometer": [ComponentMeasurement("Magnetometer", lambda : imu_reference.strMag(), UNIT.MICRO_TELSA)],
            "gyroscope": [ComponentMeasurement("Gyroscope", lambda : imu_reference.strGyro(), UNIT.RADS_PER_SEC)]
        }

        subsystems.append(imu_subsystem)
        subsystem_dict.append(imu_comp_map)
    except Exception as e:
        print(f"Unable to mount IMU Subsystem: {e}")
        
    """try:
        import rover

        rover_reference = rover.Rover()

        movement_subsystem = Subsystem("Movement", TerminalController.GREEN_ANSI)
        
        rpm_list = []
        
        for i in range(len(rover_reference._motors)):
            motor = rover_reference._motors[i]
            rpm_list += [ComponentMeasurement(f"Motor {i} RPM", lambda : motor.encoder_value(), UNIT.RPM)]
        
        movement_comp_map = {
            "rpm": rpm_list
        }

        subsystems.append(movement_subsystem)
        subsystem_dict.append(movement_comp_map)
    except Exception as e:
        print(f"Unable to mount Movement Subsystem: {e}")"""

    assert(len(subsystems) == len(subsystem_dict))
    
    return subsystems, subsystem_dict

def non_mock():
    def print_usage_message():
        print("Usage: python3 component_logger.py [options] (component_measurement_groups)")
        print("Options: [--no-write, --silent, --read-all]")
        for i in range(len(subsystem_dict)):
            print(f"{subsystems[i].name}: {list(subsystem_dict[i].keys())}")
        sys.exit(0)

    subsystem_dict = {}
    
    # no options or measure groups
    if len(sys.argv) == 1:
        print_usage_message()
        
    term_control = TerminalController()
    
    subsystems, subsystem_dict = init_subsystems()

    # default settings
    read_all = False
    is_writting_log = True
    is_std_out = True
    iter_length = 525600 * 60

    if "--no-write" in sys.argv:
        is_writting_log = False
        
    if "--no-stdout" in sys.argv:
        is_std_out = False
        
    if "-t" in sys.argv:
        index = sys.argv.index("-t")
        try:
            iter_length = int(sys.argv[index + 1])
        except:
            print("-t argument must be followed by an integer")
            print_usage_message()

    if not is_writting_log and not is_std_out:
        print("Cannot use both no-write and silent arguments")
        print_usage_message()
        
    if len(subsystems) == 0:
        print("No subsystems were found, make sure they are connected, "
              "and programmed in the 'init_subsystems' function")
        sys.exit(0)

    if "--read-all" in sys.argv:
        read_all = True
    else:
        user_subsystem_dicts = []
        for i in range(len(subsystem_dict)):
            user_subsystem_dicts.append({})
            for key in subsystem_dict[i].keys():
                if key in sys.argv: # needs proper capitalization
                    user_subsystem_dicts[i][key] = subsystem_dict[i][key]
        
        # check empty maps
        has_non_empty = False
        for i in range(len(user_subsystem_dicts)):
            if len(user_subsystem_dicts[i]) != 0:
                has_non_empty = True
                break
        
        # if nothing is specified, print the correct user options
        if not has_non_empty:
            print_usage_message()
            
    ## now add desired measurements to subsystem
    if read_all:
        for i in range(len(subsystems)):
            for key in subsystem_dict[i]:
                subsystems[i].add_component_meas_list(subsystem_dict[i][key])
    else:
        subsystem_indices_to_delete = []
        for i in range(len(subsystems)):
            if len(user_subsystem_dicts[i]) == 0:
                subsystem_indices_to_delete.append(i)
                continue
            for key in user_subsystem_dicts[i]:
                subsystems[i].add_component_meas_list(user_subsystem_dicts[i][key])
                
        for index in subsystem_indices_to_delete:
            subsystems.pop(index)
    
    num_functions = 0
    for system in subsystems:
        num_functions += system.num_measurements
    
    term_control.cursor_row = 2 + len(subsystems) + num_functions
    
    if is_writting_log and is_std_out:
        logger_stdout_trace_log(term_control, subsystems, iter_length)
    elif is_writting_log:
        logger_no_std_out(term_control, subsystems, iter_length)
    else:
        logger_no_write(term_control, subsystems, iter_length)

def main():
    if len(sys.argv) == 2 and sys.argv[1] == 'mock':
        mock_main()
    else:
        non_mock()

if __name__ == '__main__':
    main()
