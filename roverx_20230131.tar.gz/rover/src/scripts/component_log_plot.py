import ast
import sys
import os
import matplotlib.pyplot as plt

LOG_FILE = 'trace_file.log'

def read_log_file():
    with open(LOG_FILE, 'r') as in_file:
        data = in_file.readlines()
        
    return data

def save_plot(group: str, component: str):
    log_data = read_log_file()
    
    comp_values = []
    for k in range(len(log_data)):
        comp_values.append(ast.literal_eval(log_data[k])[group][component])

    plt.plot(list(range(len(log_data))), comp_values)
    plt.autoscale(True)
    plt.xlabel("Time (s)")
    plt.ylabel(f"{component.capitalize()} {group.capitalize()}") # add units
    plt.plot()
    if not os.path.exists("./graphs"):
        os.mkdir("./graphs")
    plt.savefig(f"./graphs/{component}_{group}_plot.png")
    plt.clf()

def save_all_plot():
    log_data = read_log_file()
    
    first_line_dict = dict(ast.literal_eval(log_data[0]))
    groups = list(first_line_dict.keys())
    components = [list(comp_keys.keys()) for comp_keys in first_line_dict.values()]

    for i in range(len(groups)):
        group: str = groups[i]
        for j in range(len(components[i])):
            comp_values = []
            comp: str = components[i][j]
            for k in range(len(log_data)):
                comp_values.append(ast.literal_eval(log_data[k])[group][comp])

            plt.plot(list(range(len(log_data))), comp_values)
            plt.autoscale(True)
            plt.xlabel("Time (s)")
            plt.ylabel(f"{comp.capitalize()} {group.capitalize()}") # add units
            plt.plot()
            if not os.path.exists("./graphs"):
                os.mkdir("./graphs")
            plt.savefig(f"./graphs/{comp}_{group}_plot.png")
            plt.clf()

if __name__ == '__main__':
    save_all_plot()
    #save_plot("Temperature", "Battery")
