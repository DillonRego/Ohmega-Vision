#!/bin/bash
python /home/pi/main.py
