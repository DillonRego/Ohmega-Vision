import adafruit_fxos8700
import adafruit_fxas21002c

# This module enablea support for the IMU on I2C channel 4.
from adafruit_extended_bus import ExtendedI2C as I2C

class ImuAdafruit:
    def __init__(self):
        self.i2c = I2C(4) # I2C Bus 4, should still use default addresses
        self.fxos = adafruit_fxos8700.FXOS8700(self.i2c)  # accelerometer
        self.fxas = adafruit_fxas21002c.FXAS21002C(self.i2c)  # gyroscope

    def accelerometer(self):
        return tuple(self.fxos.accelerometer)

    def magnetometer(self):
        return tuple(self.fxos.magnetometer)

    def gyroscope(self):
        return tuple(self.fxas.gyroscope)
