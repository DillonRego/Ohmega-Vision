import rover.i2c_bus as i2c
import RPi.GPIO as GPIO
import pylibi2c
import sys

from enum import Enum
from .util import PowerGPIO

class BatteryError(OSError):
    pass

class BatteryRegister():
    # ENUM for Read Type
    CELL_VOLT = 0
    PACK_CURRENT = 1
    TEMP_VOLT = 2
    VBATT_VOLT = 3
    VRGO_VOLT = 4
    ADC_VOLT = 5
    BIT_DICT = 6
    THRESHOLD = 7
    HEX_VALUE = 8

    def __init__(self, num_addr, first_address, readtype: Enum, reserved_bits = 0):
        self.num_addr = num_addr
        self.first_address = first_address
        self.readtype = readtype
        self.reserved_bits = reserved_bits

class Battery:
    "Stellar Battery i2c Interface Class"
    
    # EEPROM Register Summary (4-Byte Pages)
    OVERVOLTAGE_THRESHOLD = BatteryRegister(2, 0x0, BatteryRegister.THRESHOLD, 4)
    OVERVOLTAGE_RECOVERY = BatteryRegister(2, 0x2, BatteryRegister.HEX_VALUE, 4)
    UNDERVOLTAGE_THRESHOLD = BatteryRegister(2, 0x4, BatteryRegister.THRESHOLD, 4)
    UNDERVOLTAGE_RECOVERY = BatteryRegister(2, 0x6, BatteryRegister.HEX_VALUE, 4)
    OVERVOLTAGE_LOCKOUT_THRESHOLD = BatteryRegister(2, 0x8, BatteryRegister.HEX_VALUE, 4)
    UNDERVOLTAGE_LOCKOUT_THRESHOLD = BatteryRegister(2, 0xA, BatteryRegister.HEX_VALUE, 4)
    END_OF_CHARGE_THRESHOLD = BatteryRegister(2, 0xC, BatteryRegister.HEX_VALUE, 4)
    LOW_VOLTAGE_CHARGE_THRESHOLD = BatteryRegister(2, 0xE, BatteryRegister.HEX_VALUE, 4)
    OVERVOLTAGE_DELAY_TIMEOUT = BatteryRegister(2, 0x10, BatteryRegister.HEX_VALUE, 6)
    UNDERVOLTAGE_DELAY_TIMEOUT = BatteryRegister(2, 0x12, BatteryRegister.HEX_VALUE, 6)
    OPEN_WIRE_TIMING = BatteryRegister(2, 0x14, BatteryRegister.HEX_VALUE, 6)
    DISCHARGE_CURRENT_TIMEOUT_THRESHOLD = BatteryRegister(2, 0x16, BatteryRegister.HEX_VALUE, 1)
    CHARGE_CURRENT_TIMEOUT_THRESHOLD = BatteryRegister(2, 0x18, BatteryRegister.HEX_VALUE, 1)
    DISCHARGE_SHORT_TIMEOUT_THRESHOLD = BatteryRegister(2, 0x1A, BatteryRegister.HEX_VALUE, 1)
    CELL_BALANCE_MIN_VOLT = BatteryRegister(2, 0x1C, BatteryRegister.HEX_VALUE, 4)
    CELL_BALANCE_MAX_VOLT = BatteryRegister(2, 0x1E, BatteryRegister.HEX_VALUE, 4)
    CELL_BALANCE_MIN_DIFF_VOLT = BatteryRegister(2, 0x20, BatteryRegister.HEX_VALUE, 4)
    CELL_BALANCE_MAX_DIFF_VOLT = BatteryRegister(2, 0x22, BatteryRegister.HEX_VALUE, 4)
    CELL_BALANCE_ON_TIME = BatteryRegister(2, 0x24, BatteryRegister.HEX_VALUE, 4)
    CELL_BALANCE_OFF_TIME = BatteryRegister(2, 0x26, BatteryRegister.HEX_VALUE, 4)
    
    # RAM Register Summary
    
    # TODO: May move this to a "decrypt" bits module
    RAM_BIT_REGISTER_TABLE = \
    {
        0x80: ["OV", "OVLO", "UV", "UVLO", "DOT", "DUT", "COT", "CUT"],
        0x81: ["IOT", "COC", "DOC", "DSC", "CELLF", "OPEN", "Reserved", "EOCHG"],
        0x82: ["LD_PRSNT", "CH_PRSNT", "CHING", "DCHING", "ECC_USED", "ECC_FAIL", "INT_SCAN", "LVCHG"],
        0x83: ["CBOT", "CBUT", "CBOV", "CBUV", "IN_IDLE", "IN_DOZE", "IN_SLEEP", "Reserved"]
    }
    
    CELL_MIN_VOLT = BatteryRegister(2, 0x8A, BatteryRegister.CELL_VOLT, 4)
    CELL_MAX_VOLT = BatteryRegister(2, 0x8C, BatteryRegister.CELL_VOLT, 4)
    PACK_CURRENT = BatteryRegister(2, 0x8E, BatteryRegister.PACK_CURRENT, 4)
    
    ## should contain 8 cells
    CELL_VOLTS = [BatteryRegister(2, reg_val, BatteryRegister.CELL_VOLT, 4) for reg_val in range(0x90, 0xA0, 2)]
    
    INTERNAL_TEMP_VOLT = BatteryRegister(2, 0xA0, BatteryRegister.TEMP_VOLT, 4)
    EXTERNAL_TEMP_1_VOLT = BatteryRegister(2, 0xA2, BatteryRegister.TEMP_VOLT, 4)
    EXTERNAL_TEMP_2_VOLT = BatteryRegister(2, 0xA4, BatteryRegister.TEMP_VOLT, 4)
    VBATT_VOLT = BatteryRegister(2, 0xA6, BatteryRegister.VBATT_VOLT, 4)
    VRGO_VOLT = BatteryRegister(2, 0xA8, BatteryRegister.VRGO_VOLT, 4)
    ADC_VOLT = BatteryRegister(2, 0xAA, BatteryRegister.ADC_VOLT, 2)
    
    TOTAL_ADDR = 0xAC
    
    def __init__(self):
        """
        Initializes the I2C bus for battery communication
        """
        self.bus = pylibi2c.I2CDevice('/dev/i2c-4', 0x28)
        self.num_cells = 8
        self.enable = PowerGPIO.Jetson # change to specific battery port
        
    def __cell_voltage(self, hex_value):
        return hex_value * 1.8 * 8 / (4095 * 3)
    
    def __pack_current(self, hex_value):
        # need to note sense resistor
        # current sense resistor is usually in the range of 0.2mΩ and 5mΩ
        # may possibly need to check if current gain read works
        resistor_value = 0.001 # in Ohms
        return hex_value * 1.8 / (4095 * self.read_current_gain() * resistor_value)
    
    def __temp_voltage(self, hex_value):
        return hex_value * 1.8 / 4095
        
    # returns internal temperature in celcius
    def int_temp_celcius(self, temp_voltage, tgain = 0):
        voltage_val_mv = int(temp_voltage * 1000)
        
        if tgain == 1:
            return (voltage_val_mv / 0.92635) - 273.15
        else:
            return (voltage_val_mv / 1.8527) - 273.15
    
    # not correct yet
    def ext_temp_celcius(self, temp_voltage, tgain = 0):
        return temp_voltage
        if tgain == 1:
            return 77 + -171 * temp_voltage + 59.9 * pow(temp_voltage, 2)
        else:
            return -172 * temp_voltage + 105

    def __vbatt_voltage(self, hex_value):
        return hex_value * 1.8 * 32 / 4095
    
    def __vrgo_voltage(self, hex_value):
        return hex_value * 1.8 * 2 / 4095
    
    def __adc_voltage(self, hex_value):
        if hex_value > 8191:
            return (hex_value - 16384) * 1.8
        else:
            return hex_value * 1.8 / 8191
        
    def __bit_dict(self, reg_addr, hex_value):
        if reg_addr in self.RAM_BIT_REGISTER_TABLE:
            value_arr = self.RAM_BIT_REGISTER_TABLE[reg_addr]
            p_dict = {}
            for i in range(8):
                if 1 << i & hex_value != 0:
                    p_dict[value_arr[i]] = 1
                else:
                    p_dict[value_arr[i]] = 0
            return p_dict
        else:
            return hex_value
        
    def read_current_gain(self):
        # refer to page 56 of the Battery Documentation for values
        gain_addr = 0x85
        gain_mask = 0b00110000
        bit_shift_value = 4
        read_value = self.bus.read(gain_addr, 1)
        read_value = int(read_value.hex(), 16) # convert to int from bit array
        
        gain_bits = read_value & gain_mask
        gain_bits = gain_bits >> bit_shift_value
        
        # decoder
        if gain_bits == 0b00:
            return 50
        elif gain_bits == 0b01:
            return 5
        else:
            return 500
        
    def __threshold_voltage(self, hex_val):
        return hex_val * 1.8 * 8 / (4095 * 3)

    def __convert_register_value(self, hex_val, read_type , reg_addr):
        if read_type == BatteryRegister.CELL_VOLT:
            return self.__cell_voltage(hex_val)
        elif read_type == BatteryRegister.PACK_CURRENT:
            return self.__pack_current(hex_val)
        elif read_type == BatteryRegister.TEMP_VOLT:
            return self.__temp_voltage(hex_val)
        elif read_type == BatteryRegister.VBATT_VOLT:
            return self.__vbatt_voltage(hex_val)
        elif read_type == BatteryRegister.VRGO_VOLT:
            return self.__vrgo_voltage(hex_val)
        elif read_type == BatteryRegister.ADC_VOLT:
            return self.__adc_voltage(hex_val)
        elif read_type == BatteryRegister.BIT_DICT:
            return self.__bit_dict(reg_addr, hex_val)
        elif read_type == BatteryRegister.THRESHOLD:
            return self.__threshold_voltage(hex_val)
        elif read_type == BatteryRegister.HEX_VALUE:
            return hex_val
        else:
            print("Error invalid read type for Battery Register")
    
    # can use a statically defined register or a specific one
    def read_register(self, reg: BatteryRegister):
        hex_val = 0
        for addr_offset in range(reg.num_addr):
            
            # may raise io error
            read_value = self.bus.read(reg.first_address + addr_offset, 1)
                
            hex_val |= (int(read_value.hex(),16) << (8 * addr_offset))
        
        # need to clear the reserve space
        valid_bits = reg.num_addr * 8 - reg.reserved_bits
        mask = 0
        for i in range(valid_bits):
            mask |= 1 << i
        hex_val &= mask
        
        return self.__convert_register_value(hex_val, reg.readtype, reg.first_address)
    
    def read_register_addr(self, reg_addr: int):
        # may raise io error
        try:
            read_value = self.bus.read(reg_addr, 1)
            return read_value
        except Exception as e:
            print(e)
            return -1
    
    # caller is responsible for setting up desired write value
    def write_register(self, reg: BatteryRegister, write_value: int):
        try:
            self.bus.write(reg.first_address, write_value.to_bytes(1, sys.byteorder))
            return True
        except Exception as e:
            print(e)
            return False
            
    def write_register_addr(self, reg_addr: int, write_value: int):
        try:
            self.bus.write(reg_addr, write_value.to_bytes(1, sys.byteorder))
            return True
        except Exception as e:
            print(e)
            return False
        
    def print_all(self):
        for addr in range(Battery.TOTAL_ADDR):
            batt_reg = BatteryRegister(1, addr, BatteryRegister.HEX_VALUE, 0)
            read_value = self.read_register(batt_reg)   
            print(f"0x{batt_reg.first_address:02x}: 0x{read_value:02x}")
      
    def i2c_test(self):
        try:
            test_registers = [Battery.OVERVOLTAGE_THRESHOLD, Battery.UNDERVOLTAGE_THRESHOLD, Battery.CELL_BALANCE_MIN_VOLT, Battery.CELL_BALANCE_OFF_TIME, Battery.EXTERNAL_TEMP_1_VOLT, Battery.EXTERNAL_TEMP_2_VOLT, Battery.VBATT_VOLT,\
                Battery.DISCHARGE_SHORT_TIMEOUT_THRESHOLD]
            
            for battery_reg in test_registers:
                battery_reg.readtype = BatteryRegister.HEX_VALUE
                read_value = self.read_register(battery_reg)   
                print(f"0x{battery_reg.first_address:04x}: 0x{read_value:04x}")
                
            return True
        
        # Catch remote IO errors
        except OSError as e:
            print(e)
            return False
