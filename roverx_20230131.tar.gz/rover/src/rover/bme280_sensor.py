import i2c_bus as i2c
import RPi.GPIO as GPIO
from .util import PowerGPIO

"""
Humidity sensor measuring relative humidity, barometric pressure and ambient temperature 
"""

class BME280:
    def __init__(self):
        """
        Initializes the I2C bus for sensor communication
        """
        self.bus = i2c.I2CBus(target=0x77, dev='/dev/i2c-4')

    def i2c_read_test(self):
        try:
            if self.bus.r:
                return True
            else:
                return False
        
        # Catch remote IO errors
        except OSError as e:
            print(e)
            return False
        
    