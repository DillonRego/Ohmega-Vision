import threading
from typing import Union
from .motor import Motor, CornerMotor
from .roboclaw_3 import Roboclaw
from .util import PowerGPIO, UARTException, MotorPos, UART, RC_ADDR


class RoverEndless:
    """General class that contains all the information and methods needed to
    run the rover.
    """
    # all motors
    _motors: 'list[Union[Motor, CornerMotor]]'
    # all Roboclaws
    _uart_connections: 'list[Roboclaw]'
    # locks for each Roboclaw
    _locks: 'list[threading.Lock]'
    # movement motors
    _wheels: 'list[Motor]'
    # turning motors
    _corners: 'list[CornerMotor]'

    def __init__(self) -> None:
        """Initializes the rover. First it sets up the UART connections, then
        it sets up the motors and finally it calibrates the corners.
        """
        # setup uart connections, may raise UARTException
        self.init_uart()

        # setup the list of motors and initialize them
        self._motors = [
            Motor(self._uart_connections[UART._4], RC_ADDR.FL, 1, self._locks[UART._4]),  # front left wheel
            Motor(self._uart_connections[UART._5], RC_ADDR.FR, 1, self._locks[UART._5]),  # front right wheel
            Motor(self._uart_connections[UART._5], RC_ADDR.BL, 1, self._locks[UART._5]),  # back left wheel
            Motor(self._uart_connections[UART._4], RC_ADDR.BR, 1, self._locks[UART._4]),  # back right wheel
            Motor(self._uart_connections[UART._0], RC_ADDR.MID, 2, self._locks[UART._0]),  # middle left wheel
            Motor(self._uart_connections[UART._0], RC_ADDR.MID, 1, self._locks[UART._0]),  # middle right wheel
            CornerMotor(self._uart_connections[UART._4], RC_ADDR.FL, 2, self._locks[UART._4]),  # front left corner
            CornerMotor(self._uart_connections[UART._5], RC_ADDR.FR, 2, self._locks[UART._5]),  # front right corner
            CornerMotor(self._uart_connections[UART._5], RC_ADDR.BL, 2, self._locks[UART._5]),  # back left corner
            CornerMotor(self._uart_connections[UART._4], RC_ADDR.BR, 2, self._locks[UART._4])  # back right corner
        ]

        # get some more specific lists
        self._wheels = self._motors[MotorPos.FL:MotorPos.MR+1]
        self._corners = self._motors[MotorPos.C_FL:MotorPos.C_BR+1]

        # calibrate the corner motors forever
        while True:
            threads = []
            for motor in self._corners:
                threads.append(threading.Thread(target=motor.calibrate))
                threads[-1].start()
            for thread in threads:
                thread.join()
            self.stop_motors()

        

    def init_uart(self):
        # initialize the three uart locks
        self._locks = [
            threading.Lock(),
            threading.Lock(),
            threading.Lock()
        ]

        # initialize the three uart connections
        self._uart_connections = [
            Roboclaw("/dev/ttyS0", 115200, PowerGPIO.ML_MR),
            Roboclaw("/dev/ttyAMA3", 115200, PowerGPIO.FL_BR),
            Roboclaw("/dev/ttyAMA4", 115200, PowerGPIO.FR_BL)
        ]

        # open the connections and check if they opened successfully
        for conn in self._uart_connections:
            if conn.Open() == 0:
                raise UARTException(conn)

    def stop_motors(self, subset: 'list[Motor]' = None):
        """Stops all the motors or the ones specified

        Args:
            subset (list[Motor], optional): list of motors to stop.
            Defaults to None.
        """
        motors = subset if subset else self._motors

        for motor in motors:
            motor.stop()
