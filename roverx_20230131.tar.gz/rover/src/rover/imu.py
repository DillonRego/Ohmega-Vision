import time
from . import imu_adafruit

# "Abstract" IMU Class that instantiates specific IMU implementations
# Verify that the correct IMU Model is being used
class Imu:
    ADAFRUIT_FXOS8700 = 0
    SPARKFUN_ICM_20948 = 1

    def __init__(self, type = ADAFRUIT_FXOS8700):
        if type == Imu.ADAFRUIT_FXOS8700:
            self._imu = imu_adafruit.ImuAdafruit()
        elif type == Imu.SPARKFUN_ICM_20948:
            # need to add code for new IMU
            pass
        else:
            raise TypeError("Invalid IMU ENUM Type")

    def accelerometer(self):
        return self._imu.accelerometer()

    def magnetometer(self):
        return self._imu.magnetometer()

    def gyroscope(self):
        return self._imu.gyroscope()
    
    def strAccel(self):
        return "({0:0.4f},{1:0.4f},{2:0.4f})".format(*self.accelerometer())
    
    def strMag(self):
        return "({0:0.4f},{1:0.4f},{2:0.4f})".format(*self.magnetometer())
    
    def strGyro(self):
        return "({0:0.4f},{1:0.4f},{2:0.4f})".format(*self.gyroscope())

    def printAccel(self):
        print(
            "Acceleration (m/s^2): ({0:0.3f},{1:0.3f},{2:0.3f})".format(
                *self.accelerometer()
            )
        )

    def printMag(self):
        print(
            "Magnetometer (uTesla): ({0:0.3f},{1:0.3f},{2:0.3f})".format(
                *self.magnetometer()
            )
        )

    def printGyro(self):
        print(
            "Gyroscope (radians/s): ({0:0.3f},{1:0.3f},{2:0.3f})".format(
                *self.gyroscope()
            )
        )

    def Telementary(self, delay):
        while True:
            print(time.asctime())
            self.printAccel()
            self.printMag()
            self.printGyro()
            time.sleep(delay)