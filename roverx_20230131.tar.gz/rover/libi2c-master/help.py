import pylibi2c
help(pylibi2c)
help(pylibi2c.I2CDevice)
