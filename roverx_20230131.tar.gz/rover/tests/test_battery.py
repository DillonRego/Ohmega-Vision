import unittest
import sys

from rover.battery import Battery

bat = Battery()

class BatteryTests(unittest.TestCase):
    def test_i2c_battery(self):
        val = bat.i2c_test()
        self.assertTrue(val)
    
    def test_current_gain(self):
        gain_addr = 0x85

        # read current gain value
        gain_value = bat.read_current_gain()
        self.assertIn(gain_value, [5, 50, 500])

        read_value = bat.bus.read(gain_addr, 1)
        read_value = int(read_value.hex(), 16) # convert to int from bit array
        
        # Writing 0b01 to Current Gain Register"
        write_value = read_value & 0b11011111
        bat.bus.write(gain_addr, write_value.to_bytes(1, sys.byteorder))
        
        read_value = bat.bus.read(gain_addr, 1)
        read_value = int(read_value.hex(), 16) # convert to int from bit array
        test_value = read_value & 0b00110000
        self.assertEqual(test_value, 0b00010000)
        
        gain_value = bat.read_current_gain()
        self.assertEqual(gain_value, 5)
        
        # Writing 0b00 to Current Gain Register"
        write_value = read_value & 0b11001111
        bat.bus.write(gain_addr, write_value.to_bytes(1, sys.byteorder))
        
        read_value = bat.bus.read(gain_addr, 1)
        read_value = int(read_value.hex(), 16) # convert to int from bit array
        test_value = read_value & 0b00110000
        self.assertEqual(test_value, 0b00000000)
        
        gain_value = bat.read_current_gain()
        self.assertEqual(gain_value, 50)
    
    # set DSC registers
    def test_valid_write_DSC(self):
        
        # set to Idle Mode
        read_value = bat.read_register_addr(0x1b)
        read_value = int(read_value.hex(), 16)
        self.assertIsNotNone(read_value)
        write_value = read_value | 0x04 
        self.assertTrue(bat.write_register_addr(0x1b, write_value))
        
        read_value = bat.read_register_addr(0x1b)
        read_value = int(read_value.hex(), 16)
        test_value = read_value & 0x04
        self.assertEqual(test_value, 4)
        
        write_value = read_value & ~(0x04)
        self.assertTrue(bat.write_register_addr(0x1b, write_value))
        read_value = bat.read_register_addr(0x1b)
        read_value = int(read_value.hex(), 16)
        test_value = read_value & 0x04
        self.assertEqual(test_value, 0)

    def test_i2c_battery_2(self):
        val = bat.i2c_test()
        self.assertTrue(val)
    


# Run the unit tests.
if __name__ == '__main__':
   unittest.main()
