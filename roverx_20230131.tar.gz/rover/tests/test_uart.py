from rover.roboclaw_3 import Roboclaw

rc = Roboclaw("/dev/ttyS0", 115200, -1)
if(rc.Open() == 0):
    print("failed")
else:
    rc.GetConfig(132)
