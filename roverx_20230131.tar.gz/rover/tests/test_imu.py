import unittest

from rover.imu import Imu

class IMUTests(unittest.TestCase):
    try:
        imu_reference = Imu()
    except:
        imu_reference = None

    def test_i2c_imu(self):
        self.assertIsNotNone(self.imu_reference, "IMU not able to read I2C values")
    
    def test_accelerometer(self):
        accelerometer_val = self.imu_reference.accelerometer()
        self.assertIsInstance(accelerometer_val, tuple)
        self.assertEqual(len(accelerometer_val), 3)
        self.assertIsInstance(accelerometer_val[0], float)
        self.assertIsInstance(accelerometer_val[1], float)
        self.assertIsInstance(accelerometer_val[2], float)
        self.imu_reference.printAccel()
        
    def test_magnetometer(self):
        magnetometer_val = self.imu_reference.magnetometer()
        self.assertIsInstance(magnetometer_val, tuple)
        self.assertEqual(len(magnetometer_val), 3)
        self.assertIsInstance(magnetometer_val[0], float)
        self.assertIsInstance(magnetometer_val[1], float)
        self.assertIsInstance(magnetometer_val[2], float)
        self.imu_reference.printMag()
        
    def test_gyroscope(self):
        gyroscope_val = self.imu_reference.gyroscope()
        self.assertIsInstance(gyroscope_val, tuple)
        self.assertEqual(len(gyroscope_val), 3)
        self.assertIsInstance(gyroscope_val[0], float)
        self.assertIsInstance(gyroscope_val[1], float)
        self.assertIsInstance(gyroscope_val[2], float)
        self.imu_reference.printGyro()

# Run the unit tests.
if __name__ == '__main__':
   unittest.main()