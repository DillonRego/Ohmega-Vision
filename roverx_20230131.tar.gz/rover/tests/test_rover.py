import rover

if __name__ == "__main__":
    exo = rover.Rover()

